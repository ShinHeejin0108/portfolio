# -*- coding: utf-8 -*-
"""
Created on Sun Dec 20 18:49:40 2020

@author: gram
"""

from tkinter import *
from tkinter import ttk
from tkinter import messagebox

Grade = Tk()
Grade.title("학점 출력하기")
Grade.geometry('250x200+200+200')


def student():
    grade = e.get()
    print("학년 : " + grade)

    if (grade == "4"):
        result = "A+학점(100점)"
    elif (grade == "3"):
        result = "A학점(90점)"
    elif (grade == "2"):
        result = "B학점(80점)"
    elif (grade == "1"):
        result = "c학점(70점)"

    messagebox.showinfo("학년 별 성적", result)


score = Label(Grade, text="학년을 입력하세요(숫자만) : ")
score.pack()
e = Entry(Grade)
e.pack()

toolbar = Frame(Grade)

end = ttk.Button(Grade, text="입력 완료", command=student)

end.pack(side=TOP, padx=2, pady=2)
toolbar.pack(side=TOP, fill=X)

Grade.mainloop()