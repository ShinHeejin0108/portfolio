# -*- coding: utf-8 -*-
"""
Created on Fri Dec 18 18:07:30 2020

@author: gram
"""

from tkinter import *
from tkinter import ttk
from tkinter import messagebox

myInformation = Tk()
myInformation.geometry("400x300+200+200")
myInformation.title("개인정보 입력하기")
    
def entry():
       text = e.get() + "\n" + e1.get() + "\n" +  e2.get() + "\n" + e3.get() + "\n" +e4.get() + "\n" + e5.get() + "\n"
       messagebox.showinfo("개인정보", text)
       open("20183226_신희진.txt","w").close()
       with open("20183226_신희진.txt", "a") as f:
           f.write(text)

name = Label(myInformation, text="Name : ")
name.pack()
e = Entry(myInformation)
e.pack()

age = Label(myInformation, text="Age : ")
age.pack()
e1 = Entry(myInformation) 
e1.pack()

studentNumber = Label(myInformation, text="studentNumber : ")
studentNumber.pack()
e2 = Entry(myInformation)
e2.pack()

grade = Label(myInformation, text="Grade : ")
grade.pack()
e3 = Entry(myInformation)
e3.pack()

major = Label(myInformation, text="Major : ")
major.pack()
e4 = Entry(myInformation)
e4.pack()

email = Label(myInformation, text="Email : ")
email.pack()
e5 = Entry(myInformation)
e5.pack()

toolbar = Frame(myInformation)

b = ttk.Button(toolbar, text="입력완료", width=9, command=entry)
b.pack(side=TOP, padx=2, pady=2)
toolbar.pack(side=TOP, fill=X)

myInformation.mainloop()