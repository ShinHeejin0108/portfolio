# -*- coding: utf-8 -*-
"""
Created on Mon Dec 21 16:22:41 2020

@author: gram
"""

import pandas as pd
import matplotlib.pyplot as plt

#"data_example.txt"파일 불러오기
file = pd.read_csv('C:/Users/gram/Desktop/data_example.txt', sep='\t')
print(file)

data = {'': ['','','','','','','','','',''],
        'a' : [95,97,98,95,94,96,96,98,98,92],
        'b' : [85,91,84,87,88,90,86,84,86,86],
        'c' : [153,151,152,155,150,150,154,154,154,152],
        'd' : [-288,-285,-310,-332,-277,-260,-308,-302,-302,-286],
        'e' : [-332,-312,-318,-334,-344,-309,-285,-331,-322,-319],
        'f' : [8204,8277,8181,8171,8199,8201,8190,8211,8194,8190],
        'g' : [-29,-30,-40,-43,-27,-40,-31,-35,-34,-36],
        'h' : [36,48,50,49,34,50,47,44,43,45],
        'i' : [-23,-22,-18,-19,-21,-21,-22,-25,-24,-24]}

#df을 데이터프레임으로 변환
df = pd.DataFrame(data)
print(df)

#df의 총합
print(df.sum())
#df의 평균
print(df.mean())

#총합의 막대그래프
sum_1 = [959,867,1525,-2950,-3206,82018,-345,446,-219]
sum_2 = pd.Series(sum_1, index=list('abcdefghi'))
sum_2.plot(kind='barh')
sum_2.plot.barh()

#f를 제외한 총합 막대그래프
sum_1 = [959,867,1525,-2950,-3206,-345,446,-219]
sum_2 = pd.Series(sum_1, index=list('abcdeghi'))
sum_2.plot(kind='bar')
sum_2.plot.bar()

#평균의 막대그래프
mean_1 = [95.9,86.7,152.5,-295.0,-320.6,8201.8,-34.5,44.6,-21.9]
mean_2 = pd.Series(mean_1, index=list('abcdefghi'))
mean_2.plot(kind='barh')
mean_2.plot.barh()

#f를 제외한 평균 막대그래프
mean_1 = [95.9,86.7,152.5,-295.0,-320.6,-34.5,44.6,-21.9]
mean_2 = pd.Series(mean_1, index=list('abcdeghi'))
mean_2.plot(kind='barh')
mean_2.plot.barh()





