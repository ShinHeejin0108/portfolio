package week13;

public class StudentTest {

 public static void main(String[] args) {
  StudentList std1 = new StudentList(4);
  
  std1.append(new Student(1111, "Cathy", 20));
  std1.append(new Student(2222, "Cindy", 60));
  std1.append(new Student(3333, "Josh", 90));
  std1.append(new Student(4444, "James", 50));
  std1.append(new Student(5555, "Jenny", 80));
  std1.print();
  
  System.out.println("=========================");
  System.out.println(std1.getByName("Cindy"));
  
  System.out.println("=========================");
  std1.sortByScore();
  std1.print();
  
  System.out.println("=========================");
  System.out.println(std1.StudentAt(0));
  
  System.out.println("=========================");
  System.out.println("�������: "+std1.average());

 }

}
