package com.multicampus.board.biz.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.multicampus.board.biz.board.vo.BoardVO;
import com.multicampus.board.biz.util.JDBCUtil;

public class BoardDAO {
	// DB ���� ����
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	// SQL ���ɾ��
	private final String BOARD_INSERT = "insert into board(seq, title, writer, content,file_nm,file_save_nm) values((select nvl(max(seq), 0)+1 from board),?,?,?)";
	private final String BOARD_UPDATE = "update board set title=?, content=? where seq=?";
	private final String BOARD_DELETE = "delete board where seq=?";
	private final String BOARD_SELECT_TITLE = "select * from board where title like ? order by seq desc";
	private final String BOARD_SELECT_CONTENT = "select * from board where content like ? order by seq desc";
	private final String BOARD_SELECT_MIXED = "select * from board where title like ? or content like ? order by seq desc";
	private final String BOARD_SEARCH = "select * from board where seq=?";
	
	// �Խù� ���
	public void addBoard(BoardVO boardVO){
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(BOARD_INSERT);
			stmt.setString(1, boardVO.getTitle());
			stmt.setString(2, boardVO.getWriter());
			stmt.setString(3, boardVO.getContent());
			stmt.setString(4, boardVO.getFileName());
			stmt.setString(5, boardVO.getFileSaveName());
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeResource(stmt, conn);
		}
	}
	
	// �Խù� ����
	public void updateBoard(BoardVO boardVO){
		try {
			conn = JDBCUtil.getConnection();
			PreparedStatement stmt = conn.prepareStatement(BOARD_UPDATE);
			stmt.setString(1, boardVO.getTitle());
			stmt.setString(2, boardVO.getContent());
			stmt.setInt(3, boardVO.getSeq());
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeResource(stmt, conn);
		}
	}	
	
	// �Խù� ����
	public void deleteBoard(BoardVO boardVO){
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(BOARD_DELETE);
			stmt.setInt(1, boardVO.getSeq());
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeResource(stmt, conn);
		}
	}
	
	// �Խù� �˻�
	public BoardVO getBoard(BoardVO boardVO){
		BoardVO vo = null;
		try {
			conn = JDBCUtil.getConnection();			
			stmt = conn.prepareStatement(BOARD_SEARCH);
			stmt.setInt(1, boardVO.getSeq());
			rs = stmt.executeQuery();
			while(rs.next()){
				vo = new BoardVO();
				vo.setSeq(rs.getInt("SEQ"));
				vo.setTitle(rs.getString("TITLE"));
				vo.setWriter(rs.getString("WRITER"));
				vo.setContent(rs.getString("CONTENT"));
				vo.setRegdate(rs.getDate("REGDATE"));
				vo.setCnt(rs.getInt("CNT"));
			}	
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeResource(rs, stmt, conn);
		}
		return vo;
	}
	
	// �Խù� ��� ��ȸ
	public ArrayList<BoardVO> getBoardList(BoardVO boardVO){
		ArrayList<BoardVO> boardList = new ArrayList<BoardVO>();
		try {
			conn = JDBCUtil.getConnection();	
			if(boardVO.getSearchCondition().equals("TITLE")){
				stmt = conn.prepareStatement(BOARD_SELECT_TITLE);
				stmt.setString(1, "%"+boardVO.getSearchKeyword()+"%");
			}else if(boardVO.getSearchCondition().equals("CONTENT")){
				stmt = conn.prepareStatement(BOARD_SELECT_CONTENT);
				stmt.setString(1, "%"+boardVO.getSearchKeyword()+"%");
			}else {
				stmt = conn.prepareStatement(BOARD_SELECT_MIXED);
				stmt.setString(1, "%"+boardVO.getSearchKeyword()+"%");
				stmt.setString(2, "%"+boardVO.getSearchKeyword()+"%");
			}
			rs = stmt.executeQuery();
			while(rs.next()){
				BoardVO vo = new BoardVO();
				vo.setSeq(rs.getInt("SEQ"));
				vo.setTitle(rs.getString("TITLE"));
				vo.setWriter(rs.getString("WRITER"));
				vo.setContent(rs.getString("CONTENT"));
				vo.setRegdate(rs.getDate("REGDATE"));
				vo.setCnt(rs.getInt("CNT"));
				boardList.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeResource(rs, stmt, conn);
		}
		return boardList;
	}
}
